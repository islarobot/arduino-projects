Hardware connection:

up and donw channel connect to D16(A2)
left and right channel connect to D17(A3)


Software different:
The codes different to bluetoothcontrol only in:
uncomment this sentence:
#define RCWork true
